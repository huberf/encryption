# encryption
A minimal Python encryption class 

To setup simply type:
pip install Crypto
pip install base64

Functions:
keyGen(size=16)
encrypt(textToEncrypt, encryptionKey)
decrypt(textToDecrypt, encryptionKey)


